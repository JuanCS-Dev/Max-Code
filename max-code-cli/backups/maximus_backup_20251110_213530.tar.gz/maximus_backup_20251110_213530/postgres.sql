--
-- PostgreSQL database cluster dump
--

\restrict mgvDX4kGD7ypI3v9giinVrkjLOnUJHuXRUMurgehv5hDdGYzdn9EhO1t9xugubc

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE maximus;
ALTER ROLE maximus WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:ESU1jreK3sWcOlHDQAE6gg==$xbvUj3Ar4TBwJ3FMV6oPIjU+WtKNyt5/Ap2UxnjAUJo=:ioA5fR+wv3VeC3g88nD8Y7y57lNesGFjXH97I/spLk4=';

--
-- User Configurations
--








\unrestrict mgvDX4kGD7ypI3v9giinVrkjLOnUJHuXRUMurgehv5hDdGYzdn9EhO1t9xugubc

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict Qi8pccaRrEWqjttS563PYHukMDWIl6Qf0RN3S8FQr61Q5YCu3iXFcrwyADJZy4L

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Qi8pccaRrEWqjttS563PYHukMDWIl6Qf0RN3S8FQr61Q5YCu3iXFcrwyADJZy4L

--
-- Database "maximus" dump
--

--
-- PostgreSQL database dump
--

\restrict iZnGGiGrQJ7JOB9BpLd7TO7ADfR9XH1DsKi4Q5y1sZnuSYWQ0oklzMXDScRQdBB

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: maximus; Type: DATABASE; Schema: -; Owner: maximus
--

CREATE DATABASE maximus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE maximus OWNER TO maximus;

\unrestrict iZnGGiGrQJ7JOB9BpLd7TO7ADfR9XH1DsKi4Q5y1sZnuSYWQ0oklzMXDScRQdBB
\connect maximus
\restrict iZnGGiGrQJ7JOB9BpLd7TO7ADfR9XH1DsKi4Q5y1sZnuSYWQ0oklzMXDScRQdBB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: operator_sessions; Type: TABLE; Schema: public; Owner: maximus
--

CREATE TABLE public.operator_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    session_id character varying(255) NOT NULL,
    operator_id character varying(255) NOT NULL,
    operator_name character varying(255) NOT NULL,
    operator_role character varying(100) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_activity timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.operator_sessions OWNER TO maximus;

--
-- Name: active_sessions; Type: VIEW; Schema: public; Owner: maximus
--

CREATE VIEW public.active_sessions AS
 SELECT operator_sessions.id,
    operator_sessions.session_id,
    operator_sessions.operator_id,
    operator_sessions.operator_name,
    operator_sessions.operator_role,
    operator_sessions.ip_address,
    operator_sessions.user_agent,
    operator_sessions.created_at,
    operator_sessions.last_activity
   FROM public.operator_sessions
  WHERE (operator_sessions.last_activity > (CURRENT_TIMESTAMP - '01:00:00'::interval))
  ORDER BY operator_sessions.last_activity DESC;


ALTER TABLE public.active_sessions OWNER TO maximus;

--
-- Name: consciousness_snapshots; Type: TABLE; Schema: public; Owner: maximus
--

CREATE TABLE public.consciousness_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    arousal_level double precision NOT NULL,
    arousal_classification character varying(50) NOT NULL,
    esgt_active boolean NOT NULL,
    system_health character varying(50) NOT NULL,
    tig_metrics jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.consciousness_snapshots OWNER TO maximus;

--
-- Name: decisions; Type: TABLE; Schema: public; Owner: maximus
--

CREATE TABLE public.decisions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    decision_id character varying(255) NOT NULL,
    action_type character varying(100) NOT NULL,
    description text NOT NULL,
    risk_level character varying(50) NOT NULL,
    requires_approval boolean DEFAULT true,
    operator_id character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.decisions OWNER TO maximus;

--
-- Name: esgt_events; Type: TABLE; Schema: public; Owner: maximus
--

CREATE TABLE public.esgt_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    event_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    arousal_before double precision,
    arousal_after double precision,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.esgt_events OWNER TO maximus;

--
-- Name: healing_patches; Type: TABLE; Schema: public; Owner: maximus
--

CREATE TABLE public.healing_patches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    file_path text NOT NULL,
    patch_content text NOT NULL,
    fruit_type character varying(50),
    confidence double precision,
    applied boolean DEFAULT false,
    applied_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.healing_patches OWNER TO maximus;

--
-- Name: pending_decisions; Type: VIEW; Schema: public; Owner: maximus
--

CREATE VIEW public.pending_decisions AS
 SELECT decisions.id,
    decisions.decision_id,
    decisions.action_type,
    decisions.description,
    decisions.risk_level,
    decisions.requires_approval,
    decisions.operator_id,
    decisions.status,
    decisions.created_at,
    decisions.updated_at
   FROM public.decisions
  WHERE ((decisions.status)::text = 'pending'::text)
  ORDER BY decisions.created_at DESC;


ALTER TABLE public.pending_decisions OWNER TO maximus;

--
-- Data for Name: consciousness_snapshots; Type: TABLE DATA; Schema: public; Owner: maximus
--

COPY public.consciousness_snapshots (id, arousal_level, arousal_classification, esgt_active, system_health, tig_metrics, "timestamp") FROM stdin;
\.


--
-- Data for Name: decisions; Type: TABLE DATA; Schema: public; Owner: maximus
--

COPY public.decisions (id, decision_id, action_type, description, risk_level, requires_approval, operator_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: esgt_events; Type: TABLE DATA; Schema: public; Owner: maximus
--

COPY public.esgt_events (id, event_type, data, arousal_before, arousal_after, "timestamp") FROM stdin;
\.


--
-- Data for Name: healing_patches; Type: TABLE DATA; Schema: public; Owner: maximus
--

COPY public.healing_patches (id, file_path, patch_content, fruit_type, confidence, applied, applied_at, created_at) FROM stdin;
\.


--
-- Data for Name: operator_sessions; Type: TABLE DATA; Schema: public; Owner: maximus
--

COPY public.operator_sessions (id, session_id, operator_id, operator_name, operator_role, ip_address, user_agent, created_at, last_activity) FROM stdin;
c8610ee0-9350-497b-9065-70d508c9ab20	admin-session-001	admin	Administrator	admin	\N	\N	2025-11-11 00:33:30.889618	2025-11-11 00:33:30.889618
\.


--
-- Name: consciousness_snapshots consciousness_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.consciousness_snapshots
    ADD CONSTRAINT consciousness_snapshots_pkey PRIMARY KEY (id);


--
-- Name: decisions decisions_decision_id_key; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.decisions
    ADD CONSTRAINT decisions_decision_id_key UNIQUE (decision_id);


--
-- Name: decisions decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.decisions
    ADD CONSTRAINT decisions_pkey PRIMARY KEY (id);


--
-- Name: esgt_events esgt_events_pkey; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.esgt_events
    ADD CONSTRAINT esgt_events_pkey PRIMARY KEY (id);


--
-- Name: healing_patches healing_patches_pkey; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.healing_patches
    ADD CONSTRAINT healing_patches_pkey PRIMARY KEY (id);


--
-- Name: operator_sessions operator_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.operator_sessions
    ADD CONSTRAINT operator_sessions_pkey PRIMARY KEY (id);


--
-- Name: operator_sessions operator_sessions_session_id_key; Type: CONSTRAINT; Schema: public; Owner: maximus
--

ALTER TABLE ONLY public.operator_sessions
    ADD CONSTRAINT operator_sessions_session_id_key UNIQUE (session_id);


--
-- Name: idx_consciousness_timestamp; Type: INDEX; Schema: public; Owner: maximus
--

CREATE INDEX idx_consciousness_timestamp ON public.consciousness_snapshots USING btree ("timestamp" DESC);


--
-- Name: idx_decisions_created; Type: INDEX; Schema: public; Owner: maximus
--

CREATE INDEX idx_decisions_created ON public.decisions USING btree (created_at DESC);


--
-- Name: idx_decisions_status; Type: INDEX; Schema: public; Owner: maximus
--

CREATE INDEX idx_decisions_status ON public.decisions USING btree (status);


--
-- Name: idx_esgt_timestamp; Type: INDEX; Schema: public; Owner: maximus
--

CREATE INDEX idx_esgt_timestamp ON public.esgt_events USING btree ("timestamp" DESC);


--
-- Name: idx_sessions_operator; Type: INDEX; Schema: public; Owner: maximus
--

CREATE INDEX idx_sessions_operator ON public.operator_sessions USING btree (operator_id);


--
-- PostgreSQL database dump complete
--

\unrestrict iZnGGiGrQJ7JOB9BpLd7TO7ADfR9XH1DsKi4Q5y1sZnuSYWQ0oklzMXDScRQdBB

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict OCzeldHqDl7VeOywJG4jeHe1WhRVhwBpf60FOLWxuAE5OoOcdbuGCobt41KVHFd

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict OCzeldHqDl7VeOywJG4jeHe1WhRVhwBpf60FOLWxuAE5OoOcdbuGCobt41KVHFd

--
-- PostgreSQL database cluster dump complete
--

